package dao.exception;

public class DAOInvalidProviderTypeException extends DAOException {

    public DAOInvalidProviderTypeException() {
        super();
        // TODO Auto-generated constructor stub
    }

//	public DAOInvalidProviderTypeException(String message, Throwable cause,
//			boolean enableSuppression, boolean writableStackTrace) {
//		super(message, cause, enableSuppression, writableStackTrace);
//	}

    public DAOInvalidProviderTypeException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public DAOInvalidProviderTypeException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public DAOInvalidProviderTypeException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
