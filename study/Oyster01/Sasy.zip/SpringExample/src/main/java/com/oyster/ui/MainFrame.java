package com.oyster.ui;

import javax.swing.*;

/**
 * @author bamboo
 * @since 4/13/14 7:49 PM
 */
public class MainFrame extends JFrame {

    public MainFrame() {
        super("KPI City");
    }
}
