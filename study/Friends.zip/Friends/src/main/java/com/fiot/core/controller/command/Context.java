package com.fiot.core.controller.command;

import java.util.HashMap;

/**
 * Клас відображає контекст команди
 *
 * @author bamboo
 */
public class Context extends HashMap<String, Object> {
}
